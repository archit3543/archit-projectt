from django.apps import AppConfig


class SclwebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sclWeb'
